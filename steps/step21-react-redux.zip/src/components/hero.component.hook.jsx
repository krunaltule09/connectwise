import { useDispatch, useSelector } from 'react-redux';
import addHero from '../redux';
function HeroHookComp(){
    const numberOfHeroes = useSelector( state => state.numberOfHeroes  );
    const dispatch = useDispatch();
    return <div>
                <h1>Avengers Enrollment Program Using Hooks</h1>
                <h2>Number of Avengers Recruited : { numberOfHeroes } </h2>
                <button onClick={ ()=>{ dispatch( addHero() ) } }>Add Avenger</button>
            </div>
}

export default HeroHookComp;