import { Component } from 'react';
import "./mystyle.css";
export class ChildComp extends Component{
state = {
    username : '',
    userage : 0,
    usermail : '',
    userAgeError : ''
    }
    userNameChangeHandler = (evt)=>{
        this.setState({
            ...this.state,
            username : evt.target.value
        })
    }
    userAgeChangeHandler = (evt)=>{
        this.setState({
            ...this.state,
            userage : evt.target.value
        })
    }
    userMailChangeHandler = (evt)=>{
        this.setState({
            ...this.state,
            usermail : evt.target.value
        })
    }
    formSubmitHandler = (evt)=>{
        evt.preventDefault();
        if(this.state.userage < 18){
            this.setState({
                ...this.state,
                userAgeError : "You are too young to join us"
            })
        }else if( this.state.userage > 80){
            this.setState({
                ...this.state,
                userAgeError : "You are too old to join us"
            })
        }else{
            this.setState({
                ...this.state,
                userAgeError : ""
            });
            evt.target.submit();
        }
    }
  render(){
    return <div>
            <h1>User Registeration</h1>
            <form onSubmit={ this.formSubmitHandler }>
                <div className="mb-3">
                    <label htmlFor="uname" className="form-label">User Name</label>
                    <input onInput={ this.userNameChangeHandler } value={ this.state.username } name="uname" type="text" className="form-control" id="uname"/>
                </div>
                <div className="mb-3">
                    <label htmlFor="uage" className="form-label">User Age</label>
                    <input onInput={ this.userAgeChangeHandler } value={ this.state.userage } name="uage" type="number" className="form-control" id="uage"/>
                    <div className="form-text errortext">{ this.state.userAgeError }</div>
                </div>
                <div className="mb-3">
                    <label htmlFor="umail" className="form-label">User eMail</label>
                    <input onInput={ this.userMailChangeHandler } value={ this.state.usermail } name="umail" type="text" className="form-control" id="umail"/>
                </div>
                <button type="submit" className="btn btn-primary">Submit</button>
            </form>
            <hr />
            <ul>
                <li>User Name : { this.state.username }</li>
                <li>User Age : { this.state.userage }</li>
                <li>User eMail : { this.state.usermail }</li>
            </ul>
           </div>
  }
}