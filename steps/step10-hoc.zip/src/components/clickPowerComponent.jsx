
import { Component } from 'react';
import WithPowerStyle from './withPowerStyle';

class ClickPowerComp extends Component{
    render(){
        return <div style={ this.props.compstyle }>
                <h1>{ this.props.message } | Version : { this.props.version }</h1>
                <h2>{ this.props.title }</h2>
                <hr/>
                <h2>Power is : { this.props.power }</h2>
                <button onClick={ this.props.increasepower }>Increase Power</button>
               </div>
    }
}

// export default ClickPowerComp;

export default WithPowerStyle(ClickPowerComp)