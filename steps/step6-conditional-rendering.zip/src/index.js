import { Component } from 'react';
import ReactDOM from 'react-dom';

class ChildComp extends Component{
  render(){
    return <div>
            <h1>Child Component</h1>
            <p>
                Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quam vero, vel accusantium odio officiis provident animi atque consequatur praesentium dolores voluptate vitae sunt corporis est reprehenderit perferendis tempore temporibus! Praesentium.
            </p>
           </div>
  }
}

class MainApp extends Component{
  state = {
    show : true
  }
  render(){
    /* if(this.state.show){
      return <div className="container">
                <h1>Welcome to your life | Child Component is Shown</h1>
                <button onClick={()=>{ this.setState({ show: !this.state.show })}}>Show / Hide</button>
                <hr/>
                <ChildComp/>
              </div>
    }else{
      return <div className="container">
              <h1>Welcome to your life | Child Component is Hidden</h1>
              <button onClick={()=>{ this.setState({ show: !this.state.show })}}>Show / Hide</button>
            </div>
    }
  } */

  return <div className="container">
              <h1>Welcome to your life | Child Component is Shown</h1>
              {
                this.state.show && <h2>Show is set to True</h2>
              }
              <button onClick={()=>{ this.setState({ show: !this.state.show })}}>Show / Hide</button>
              <hr/>
              {
               this.state.show ?  <ChildComp/> : "Child comp is hidded"
              }
          </div>
}
}

ReactDOM.render(<MainApp/>,document.getElementById('root'));