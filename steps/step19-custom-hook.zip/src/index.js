import { useState } from 'react';
import ReactDOM from 'react-dom';
import AjaxComp from './components/ajaxComp';
import ChildComp from './components/childcomp';
import useToggle from './hooks/useToggle';

function MainApp(){
  // let [show, toggleShow] = useState(false); 
  let [show, toggleShow] = useToggle(); 
  let [power, accessPower] = useState(0); 
  let [version, accessVersion] = useState(0); 

  return <div className="container">
           <h1>Main App Component</h1>
           <button onClick={ ()=> toggleShow()}>Show / Hide</button>
           <button onClick={ ()=> accessPower(power+1) }>Increase Power</button>
           <button onClick={ ()=> accessVersion(version+1) }>Increase Version</button>
           <hr/>
           {
               show ? <ChildComp ver={ version } pow={ power }/> : "Child Component is Hidden"
           }
           <hr/>
           <AjaxComp/>
         </div>
}

ReactDOM.render(<MainApp/>,document.getElementById('root'));