import { Component } from 'react';
import ReactDOM from 'react-dom';
import { Provider } from 'react-redux';
import store from './redux/store';
import HeroComp from './components/hero.component';
import HeroHookComp from './components/hero.component.hook';

class MainApp extends Component{
  render(){
    return <div className="container">
            <h1>Welcome React Redux</h1>
            <Provider store={ store }>
              <HeroComp/>
              <HeroHookComp/>
            </Provider>
           </div>
  }
}

ReactDOM.render(<MainApp/>,document.getElementById('root'));