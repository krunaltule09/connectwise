import { Component } from 'react';
import ReactDOM from 'react-dom';
import ChildComp from './components/childComp';

class MainApp extends Component{
  state = {};
  constructor(){
    super();
    this.state = {
      power : 5
    }
    console.log("MainApp's constructor was called");
  }
  static getDerivedStateFromProps(){
    console.log("MainApp's getDerivedStateFromProps was called");
    return true;
    /* return {
      power : 10
    } */
  }
  componentDidMount(){
    console.log("MainApp's componentDidMount was called");
  }
  increasePower = ()=>{
    this.setState({
      power : this.state.power + 1
    })
  }
  render(){
    console.log("MainApp's render was called");
    return <div className="container">
            <h1>Lifecycle Events | Power : { this.state.power }</h1>
            <button onClick={ this.increasePower }>Increase Power</button>
            <hr/>
            {
              this.state.power < 9 &&  <ChildComp pow={ this.state.power }/>
            }
           </div>
  }
}

ReactDOM.render(<MainApp/>,document.getElementById('root'));