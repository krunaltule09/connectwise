import { Component } from 'react';

class AquamanComp extends Component{
  render(){
    return <div>
            <h1>Aquaman Component</h1>
           </div>
  }
}
export default AquamanComp;