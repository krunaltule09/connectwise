import { Component } from 'react';
import ReactDOM from 'react-dom';
import axios from 'axios';

class MainApp extends Component{
  state = {
    posts : []
  }
  componentDidMount(){
    this.refresh();
  }
  refresh(){
   axios
   .get("https://jsonplaceholder.typicode.com/posts")
   .then((res)=> this.setState({ posts : res.data}) )
   .catch((err)=> console.log("Error : ", err))
  }
  render(){
    return <div className="container">
            <h1>Welcome to your life</h1>
            <div style={ {height : "400px", overflow : "auto"}}>
              { this.state.posts.length > 0 ? this.state.posts.map(function(val){
                return <div className="card"  key={ val.id }>
                        <h5 className="card-header">Title { val.title }</h5>
                        <div className="card-body">
                          <h6 className="card-subtitle">Category : { val.userId }</h6>
                          <p className="card-text">{ val.body }</p>
                        </div>
                      </div>
              }) : "nothing to show" }
            </div>
           </div>
  }
}

ReactDOM.render(<MainApp/>,document.getElementById('root'));