import { Component } from 'react';
import ReactDOM from 'react-dom';

class App extends Component{
  state = {
    power : 5
  }
  render(){
    return <div className="container">
            <h1>Welcome to your life</h1>
            <h2> Power is : { this.state.power }</h2>
           </div>
  }
}

export default App