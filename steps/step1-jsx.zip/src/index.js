import React, { Component, Fragment } from 'react';
import ReactDOM from 'react-dom';
/*
always return a single dom node, React.Fragment or <>
use className instead of class attribute
use htmlFor instead of for attribute
use camel cased event types
while applying inline style use expression that takes a style configuration
style property names are camel cased 
inline elements needs to be closed
-------------------------------------
functions that return JSX element must start with uppercase
  use lower case tagnames for inbuilt DOM elements
  usd uppercase tagnames for custom elements

*/


function CompThree(){
  return <div className="box">
            <h2> Third Child function Component</h2>
          </div>
}
class ChildComp extends Component{
  render(){
    return <>
                <div className="box">
                  <h1>1 Child Component</h1>
                  <label htmlFor="ti1"> Your Email Id : 
                    <input id="ti1"/>
                  </label>
                  <button>Click Me</button>
                </div>
                <div className="box">
                  <h1 style={ { fontFamily : 'arial', backgroundColor : 'orangered' } }>2 Child Component</h1>
                </div>
           </>
  }
}
class MainApp extends Component{
  render(){
    return <div>
            <h1>Welcome to your life</h1>
            <hr/>
            <ChildComp/>
            <hr/>
            <CompThree/>
           </div>
  }
}

ReactDOM.render(<MainApp/>,document.getElementById('root'));
