/* import { Component } from 'react';
import FamilyContext from '../context/family.context';

class ChildComponent extends Component{
  render(){
    return <div style={ {border : "2px solid grey ", padding : "10px", margin : "10px" }}>
            <h1>Child Component </h1>
            <FamilyContext.Consumer>{
              (val)=>{
                return <h2>{ val }</h2>
              }
              }</FamilyContext.Consumer>
           </div>
  }
}

export default ChildComponent; */

/* import FamilyContext from '../context/family.context';


function ChildComponent(){
  return <div style={ {border : "2px solid grey ", padding : "10px", margin : "10px" }}>
            <h1>Child Component </h1>
            <FamilyContext.Consumer>{
              (val)=>{
                return <h2>{ val }</h2>
              }
              }</FamilyContext.Consumer>
           </div>

}

export default ChildComponent; */


import { useContext } from 'react';
import FamilyContext from '../context/family.context';


function ChildComponent(){
  let val = useContext(FamilyContext);
  return <div style={ {border : "2px solid grey ", padding : "10px", margin : "10px" }}>
            <h1>Child Component </h1>
            <h2>Message : { val }</h2>
         </div>

}

export default ChildComponent;