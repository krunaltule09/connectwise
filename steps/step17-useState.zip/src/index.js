/* Step 1
import { useState } from 'react';
import ReactDOM from 'react-dom';

function MainApp(){
    // console.log(useState());
    let [power, accessPower] = useState(0);
    return <div className="container">
            <h1>Welcome to your life</h1>
            <h2>Power : {power}</h2>
            <button onClick={ ()=> accessPower(power+1) }>Increase Power</button>
           </div>
}

ReactDOM.render(<MainApp/>,document.getElementById('root')); 
*/
import { useState } from 'react';
import ReactDOM from 'react-dom';

function MainApp(){
    let [user, accessUser] = useState({ firstname : 'default first name', lastname : 'default last name'});
    return <div className="container">
            <h1>Welcome to your life</h1>
            <ul>
                <li>First Name : { user.firstname }</li>
                <li>Last Name : { user.lastname }</li>
            </ul>
            <label htmlFor="fname">First Name : 
                <input onInput={(evt)=>{ accessUser({...user, firstname : evt.target.value }) }} id="fname" type="text" value={ user.firstname }/>
            </label>
            <br/>
            <label htmlFor="lname">Last Name : 
                <input onInput={(evt)=>{ accessUser({...user, lastname : evt.target.value }) }} id="lname" type="text" value={ user.lastname }/>
            </label>
           </div>
}

ReactDOM.render(<MainApp/>,document.getElementById('root'));