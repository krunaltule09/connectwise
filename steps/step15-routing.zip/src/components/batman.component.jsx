import { Component } from 'react';

class BatmanComp extends Component{
  render(){
    return <div>
            <h1>Batman Component</h1>
           </div>
  }
}
export default BatmanComp;