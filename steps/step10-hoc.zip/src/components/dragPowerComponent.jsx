import { Component } from 'react';
import WithPowerStyle from './withPowerStyle';

class DragPowerComp extends Component{
    render(){
        return <div  style={ this.props.compstyle } >
                <h1>{ this.props.message } | Version : { this.props.version }</h1>
                <h2>{ this.props.title }</h2>
                <hr/>
                <h2>Power is : { this.props.power }</h2>
                <div  onMouseMove={ this.props.increasepower } style={ { width : '200px', backgroundColor : "orangered", height: "50px", textAlign : "center", color : "papayawhip", lineHeight : "50px", cursor : "pointer"} }> Drag Mouse Over </div>
               </div>
    }
}

export default WithPowerStyle(DragPowerComp);