import { Component } from 'react';
import ReactDOM from 'react-dom';
import GrandParentComponent from './components/grandparent.component';

class MainApp extends Component{
  render(){
    return <div className="container">
            <h1>Welcome to your life</h1>
            <hr/>
            <GrandParentComponent/>
           </div>
  }
}

ReactDOM.render(<MainApp/>,document.getElementById('root'));