import React, { Component } from 'react';
import ReactDOM from 'react-dom';

class PopUpComponent extends Component{
  render(){
    return ReactDOM.createPortal(
        this.props.children,
        document.getElementById('player'))
  }
}
class MainApp extends Component{
    state = {
        showPopUp : true
    }
    doShowHide = ()=>{
        this.setState({
            showPopUp : !this.state.showPopUp
        })
    }
  render(){
      return <div className="container">
                <h1>Welcome to your life</h1>
                
                <h3> Terms and Conditions </h3>
                { 
                this.state.showPopUp 
                ? 
                <button onClick={ this.doShowHide }>Show Popup</button> 
                : 
                <PopUpComponent>
                    <div style={ { position : "relative"}}> 
                        <h1>Hello from popup</h1> 
                        <p>
                            Lorem ipsum, dolor sit amet consectetur adipisicing elit. Dolore praesentium cumque aliquid odio? Quas praesentium eaque placeat illo enim doloremque, optio consequatur ut ipsa libero quisquam nam dicta, fugiat obcaecati?  
                        </p>
                        <button style={ { position : 'absolute', top : "0px", right : "0px"}} onClick={ this.doShowHide }> X </button>
                    </div>
                </PopUpComponent> 
                }
            </div>
    
  }
}

ReactDOM.render(<MainApp/>,document.getElementById('root'));
