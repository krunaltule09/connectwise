import axios from 'axios';
import { useEffect, useState } from 'react';

function AjaxComp(){
    let [posts, managePosts] = useState([]);

    useEffect(()=>{
        refresh();
    },[]);

  let refresh = ()=>{
   axios
   .get("https://jsonplaceholder.typicode.com/posts")
   .then((res)=> managePosts(res.data) )
   .catch((err)=> console.log("Error : ", err))
  }
  return <div className="container">
            <h1>Welcome to your life</h1>
            <div style={ {height : "400px", overflow : "auto"}}>
              { posts.length > 0 ? posts.map(function(val){
                return <div className="card"  key={ val.id }>
                        <h5 className="card-header">Title { val.title }</h5>
                        <div className="card-body">
                          <h6 className="card-subtitle">Category : { val.userId }</h6>
                          <p className="card-text">{ val.body }</p>
                        </div>
                      </div>
              }) : "nothing to show" }
            </div>
           </div>
}

export default AjaxComp;