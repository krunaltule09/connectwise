import { Component } from 'react';
import ReactDOM from 'react-dom';
import ClickPowerComp from './components/clickPowerComponent';
import DragPowerComp from './components/dragPowerComponent';

class MainApp extends Component{
  render(){
    return <div className="container">
            <h1>Higher Order Components</h1>
            <hr/>
            <ClickPowerComp message='Click Power Component !!! ' version={ 101 }/>
            <DragPowerComp message='Drag Power Component !!! ' version={ 201 }/>
           </div>
  }
}

ReactDOM.render(<MainApp/>,document.getElementById('root'));
