import { Component } from 'react';

class HeroComp extends Component{
  render(){
   if( this.props.power > 5){
       return  <div>
                <h1>Hero Component | Power : { this.props.power }</h1>
               </div>
   }else{
       throw new Error("Hero can't participate in the war")
   }
  }
}

export default HeroComp;