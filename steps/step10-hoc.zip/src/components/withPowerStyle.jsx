import { Component } from "react";

/* 
let WithPowerStyle = (OriginalComp)=>{
    return OriginalComp;
}; 
*/

let WithPowerStyle = (OriginalComp)=>{
    class HOComp extends Component{
        compStyle = {
            border : "5px solid silver", 
            padding : "10px", 
            margin : "10px"
        }
        state = {
            power : 0
        }
        increasePower = ()=>{
            this.setState({
                power : this.state.power+1
            })
        }
        render(){
            // return <OriginalComp message={ this.props.message } version={ this.props.version } compstyle={ this.compStyle } power = { this.state.power } increasepower={ this.increasePower } title="Higher Order Component"/>
            return <OriginalComp { ...this.props } compstyle={ this.compStyle } power = { this.state.power } increasepower={ this.increasePower } title="Higher Order Component"/>
        }
    }
    return HOComp;
};

export default WithPowerStyle;