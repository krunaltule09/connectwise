import { Component } from 'react';
import ReactDOM from 'react-dom';
import { ChildComp } from './components/formcomp';

class MainApp extends Component{
  render(){
    return <div className="container">
            <ChildComp/>
           </div>
  }
}

ReactDOM.render(<MainApp/>,document.getElementById('root'));