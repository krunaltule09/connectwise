import { Component } from 'react';
import ReactDOM from 'react-dom';
import {BrowserRouter, Route, Switch, Link, HashRouter, NavLink } from 'react-router-dom';
import HomeComp from './components/home.component';
import BatmanComp from './components/batman.component';
import SupermanComp from './components/superman.component';
import AquamanComp from './components/aquaman.component';
import NotFoundComp from './components/notfound.component';

import "./mystyle.css";

/*
 <ul>
    <li> <Link to="/">Home</Link> </li>
    <li> <Link to="/batman">Batman</Link> </li>
    <li> <Link to="/aquaman">Aquaman</Link> </li>
    <li> <Link to={'/superman/'+this.state.quantity}>Superman</Link> </li>
    <li> <Link to="/hulk">Hulk</Link> </li>
    <li> <Link to="/captain">Captain</Link> </li>
</ul>


<ul>
    <li> <NavLink activeStyle={this.styleprop} exact to="/">Home</NavLink > </li>
    <li> <NavLink activeStyle={this.styleprop}  to="/batman">Batman</NavLink > </li>
    <li> <NavLink activeStyle={this.styleprop}  to="/aquaman">Aquaman</NavLink > </li>
    <li> <NavLink activeStyle={this.styleprop}  to={'/superman/'+this.state.quantity}>Superman</NavLink > </li>
    <li> <NavLink activeStyle={this.styleprop}  to="/hulk">Hulk</NavLink > </li>
    <li> <NavLink activeStyle={this.styleprop}  to="/captain">Captain</NavLink > </li>
</ul>


*/
class MainApp extends Component{
  state = {
    quantity : 0
  }
  increaseHandler = (evt)=>{
    this.setState({
      quantity : evt.target.value
    })
  }
  styleprop = {
    fontWeight: "bold", color: "red"
  }
  render(){
    return <div className="container">
            <h1>Welcome to Heroes Application</h1>
            <div>
              <input type="range" value={ this.state.quantity } onInput={ this.increaseHandler }/>
              &nbsp;
              &nbsp;
              <span style={ {color : "crimson", fontFamily:"Trebuchet MS", fontSize : "24px"} }> Quantity : { this.state.quantity }</span>
            </div>
            <BrowserRouter>
              <ul>
                  <li> <NavLink activeClassName="boxer"  exact to="/">Home</NavLink > </li>
                  <li> <NavLink activeClassName="boxer"  to="/batman">Batman</NavLink > </li>
                  <li> <NavLink activeClassName="boxer"  to="/aquaman">Aquaman</NavLink > </li>
                  <li> <NavLink activeClassName="boxer"  to={'/superman/'+this.state.quantity}>Superman</NavLink > </li>
                  <li> <NavLink activeClassName="boxer"  to="/hulk">Hulk</NavLink > </li>
                  <li> <NavLink activeClassName="boxer"  to="/captain">Captain</NavLink > </li>
              </ul>
               <Switch>
                <Route path="/" exact component={ HomeComp }/>
                <Route path="/batman" component={ BatmanComp }/>
                <Route path="/aquaman" component={ AquamanComp }/>
                <Route path="/superman/:qty" component={ SupermanComp }/>
                <Route component={ NotFoundComp }/>
               </Switch>
            </BrowserRouter>
           </div>
  }
}

ReactDOM.render(<MainApp/>,document.getElementById('root'));
