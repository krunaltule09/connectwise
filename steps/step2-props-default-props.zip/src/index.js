import { Component } from 'react';
import ReactDOM from 'react-dom';
import PropTypes from 'prop-types';

class ChildComp extends Component{
  /*   
  constructor(){
    super()
  } 
  */
/*  */
static defaultProps = {
   title : "default title",
   ver : 1
 } 
static propTypes = {
  title : PropTypes.string.isRequired,
  ver : PropTypes.number.isRequired
}

  render(){
    return <div>
            <h1>Child Component</h1>
            <h2>String : { this.props.title }</h2>
            <h2>Number : { this.props.ver }</h2>
           </div>
  }
}

class MainApp extends Component{
  render(){
    return <div className="container">
            <h1>Main Application</h1>
            <hr/>
            <ChildComp ver={101} title="String Title One "/>
            <ChildComp title="String Title Two"/>
            <ChildComp ver={103} />
            <ChildComp />
           </div>
  }
}

ReactDOM.render(<MainApp/>,document.getElementById('root'));