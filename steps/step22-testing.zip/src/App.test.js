import App from "./App";

describe("testing for power", function(){
  let app = null;

  beforeEach(()=>{
    app = new App();
    console.log("Before Each called")
  });

  it("should have power", function(){
    expect(app.state.power).toBeDefined();
  })

  it("should check power to be 5", function(){
    expect(app.state.power).toBe(5);
  })

  it("should check power to be less than 10", function(){
    expect(app.state.power).toBeLessThan(10);
  })

  afterEach(()=>{
    app = null;
    console.log("After Each called")
  });


})