import { Component } from "react";
import { connect } from 'react-redux';
import addHero from "../redux";


// map state to props
const mapStateToProps = (state)=>{
    return {
        numberOfHeroes : state.numberOfHeroes
    }
}

// map dispatch to props
const mapDispatchToProps = (dispatch)=>{
    return {
        addHero : ()=> { dispatch( addHero() )}
    }
}


class HeroComp extends Component{
    render() {
        return <div>
                    <h1>Avengers Enrollment Program</h1>
                    <h2>Number of Avengers Recruited : { this.props.numberOfHeroes } </h2>
                    <button onClick={ this.props.addHero }>Add Avenger</button>
                </div>
    }
}

export default connect(mapStateToProps, mapDispatchToProps)(HeroComp)