import { Component } from 'react';
import ReactDOM from 'react-dom';

class ChildComp extends Component{
  state = {
    version : 0
  }
/* 
  constructor(){
    super();
    // this.clickHandler = this.clickHandler.bind(this);
  } 
*/
  clickHandler = ()=>{
      /*       
      this.setState({
        version : this.state.version + 1
      }, function(){
        console.log(this.state.version);
      }); 
      */
      /* */
      this.setState(function(state, props){
        return {
          version : props.ver
        }
      }, function(){
        console.log(this.state.version);
      }); 
      
/*       this.setState(function(state, props){
        return {
          version : state.version + 1
        }
      }, function(){
        console.log(this.state.version);
      });  */
  }
  render(){
    return <div>
            <h1>Child Component Version : { this.state.version }</h1>
            <h1>Parent Component Version : { this.props.ver }</h1>
            <button onClick={ this.clickHandler }>Increase version</button>
           </div>
  }
}

class MainApp extends Component{
  state = {
    stateVer : 10
  }
  render(){
    return <div className="container">
            <h1>Welcome to your life | stateVersion : { this.state.stateVer }</h1>
            <input onInput={ (evt)=> this.setState({ stateVer : evt.target.value })} type="range"/>
            <hr/>
            <ChildComp ver={this.state.stateVer} title="hello child comp"/>
           </div>
  }
}

ReactDOM.render(<MainApp/>,document.getElementById('root'));