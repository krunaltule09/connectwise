import { useEffect } from "react";

function ChildComp(props){
   /*  
    useEffect(()=> console.log("Child Comp Mounted "),[]);
    useEffect(()=> console.log("Power property was updated", props.pow ),[props.pow]);
    useEffect(()=>{
        return ()=>{
            console.log("Child Comp Unmounted");
        }
    },[]); 
    */

    useEffect(()=>{
        console.log("Power property was updated", props.pow )
        return ()=>{
            console.log("Child Comp Unmounted");
        }
    },[props.pow]);
    
  return <div className="container">
           <h1>Child Comp</h1>
           <ul>
               <li>Power : { props.pow }</li>
               <li>Version : { props.ver }</li>
           </ul>
         </div>
}

export default ChildComp;