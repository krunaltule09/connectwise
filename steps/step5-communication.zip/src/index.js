import { Component } from 'react';
import ReactDOM from 'react-dom';

class ChildComp extends Component{
  render(){
    return <div>
            <h1>Child Component</h1>  
            <h2> Power : { this.props.power }</h2>
            <h2> Message : { this.props.message }</h2>
            <button onClick={()=>{ this.props.powerChanger(10) }}>Set Parent Power to 10</button>
            <input onChange={ (evt)=> this.props.messageChanger(evt.target.value) }/>
           </div>
  }
}

class MainApp extends Component{
  state = {
    power : 0,
    message : "empty"
  }
  increasePowerHandler = (evt)=>{
    this.setState({
      power : evt.target.value
    })
  }
  assignPowerHandler = (val)=>{
    this.setState({
      power : val
    })
  }
  assignMessageHandler = (msg)=>{
    this.setState({
      message : msg
    })
  }
  messageHandler = (evt)=>{
    this.setState({
      message : evt.target.value
    })
  }
  render(){
    return <div className="container">
            <h1>Welcome to your life</h1>
            <h2> Power : { this.state.power }</h2>
            <h2> Message : { this.state.message }</h2>
            <input type="range" onInput={ this.increasePowerHandler }/>
            <input type="text" onInput={ this.messageHandler }/>
            <hr/>
            <ChildComp messageChanger={ this.assignMessageHandler } powerChanger={ this.assignPowerHandler } power={ this.state.power } message={ this.state.message } />
           </div>
  }
}

ReactDOM.render(<MainApp/>,document.getElementById('root'));