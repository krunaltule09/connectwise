import { Component } from 'react';
import ReactDOM from 'react-dom';
import ErrorManager from './components/errorManager';
import HeroComp from './components/hero';

class MainApp extends Component{
  render(){
    return <div className="container">
            <h1>Error Management</h1>
            <hr/>
            <ErrorManager>1 
                <HeroComp power={ Math.round(Math.random() * 20 ) }/>
            </ErrorManager>
            <ErrorManager>2 
                <HeroComp power={ Math.round(Math.random() * 20 )  }/>
            </ErrorManager>
            <ErrorManager>3 
                <HeroComp power={ Math.round(Math.random() * 20 )  }/>
            </ErrorManager>
            <ErrorManager>4 
                <HeroComp power={ Math.round(Math.random() * 20 )  }/>
            </ErrorManager>
           </div>
  }
}

ReactDOM.render(<MainApp/>,document.getElementById('root'));
