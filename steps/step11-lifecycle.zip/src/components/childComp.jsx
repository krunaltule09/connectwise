import { Component } from 'react';

class ChildComp extends Component{
    count = 0;
    resetval = []
    state = { elixir : 0 };
    constructor(){
        super();
        console.log("ChildComp's constructor was called");
    }
    static getDerivedStateFromProps(prop){
        console.log("ChildComp's getDerivedStateFromProps was called");
        console.log(arguments[0], arguments[1]);
        return {
            elixir : prop.pow
        }
    }
    componentDidMount(){
        console.log("ChildComp's componentDidMount was called");
    }
    shouldComponentUpdate(prop, state){
        console.log("ChildComp's shouldComponentUpdate was called");
        if(prop.pow <= 10){
            return true;
        }else{
            return false;
        }
    }
    componentDidUpdate(){
        console.log("ChildComp's componentDidUpdate was called");
    }
    getSnapshotBeforeUpdate(){
        console.log("ChildComp's getSnapshotBeforeUpdate was called");
        // console.log(arguments[0], arguments[1]);
        // this.resetval = arguments[0];
        // console.log(this.resetval);
        this.count++;
        /* let keyname = "undo"+this.count;
        let obj = {
            keyname+"" : arguments[0]
        } */
        this.resetval.push(arguments[0]);
        console.log(this.resetval);
        return true;
    }
    componentWillUnmount(){
        console.log("ChildComp's componentWillUnmount was called");
    }
    render(){
        console.log("ChildComp's render was called");
        return <div>
                <h1>Child Component</h1>
                <h2>Power : { this.state.elixir }</h2>
               </div>
    }
}

export default ChildComp;