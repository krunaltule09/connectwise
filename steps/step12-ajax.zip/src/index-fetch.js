import { Component } from 'react';
import ReactDOM from 'react-dom';
import fetch from 'fetch';

class MainApp extends Component{
  state = {
    posts : []
  }
  componentDidMount(){
    this.refresh();
  }
  refresh(){
    fetch.fetchUrl("https://jsonplaceholder.typicode.com/posts", (err, meta, data)=>{
      if(err){
        console.log("Error Message : ", err);
      }else{
        this.setState({
          posts : JSON.parse(data)
        }) 
        // console.log(data);
        // console.log(JSON.parse(data));
      }
    })
  }
  render(){
    return <div className="container">
            <h1>Welcome to your life</h1>
            <div style={ {height : "400px", overflow : "auto"}}>
              { this.state.posts.length > 0 ? this.state.posts.map(function(val){
                return <div className="card"  key={ val.id }>
                        <h5 className="card-header">Title { val.title }</h5>
                        <div className="card-body">
                          <h6 className="card-subtitle">Category : { val.userId }</h6>
                          <p className="card-text">{ val.body }</p>
                        </div>
                      </div>
              }) : "nothing to show" }
            </div>
           </div>
  }
}

ReactDOM.render(<MainApp/>,document.getElementById('root'));