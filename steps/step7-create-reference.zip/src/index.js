import React, { Component } from 'react';
import ReactDOM from 'react-dom';

class MainApp extends Component{
  state = {
    power : 0
  }

  ipRef = React.createRef();

  increasePowerHandler = ()=>{
    this.setState({
      power : this.state.power + 1
    })
  }
  decreasePowerHandler = ()=>{
    this.setState({
      power : this.state.power - 1
    })
  }
  setInputPower = (evt)=>{
    this.setState({
      power : Number( evt.target.value )
    })
  }
/*   setPowerFromNumber = (val)=>{
    this.setState({
      power : Number( val )
    })
  } */
  setPowerFromNumber = ()=>{
    this.setState({
      power : Number( document.getElementById("box").value )
    })
  }
  render(){
    return <div className="container">
            <h1>Welcome to your life</h1>
            <h2>Power : { this.state.power }</h2>
            <button className="btn btn-primary" onClick={ this.increasePowerHandler }>Increase Power</button>
            &nbsp;
            &nbsp;
            <button className="btn btn-primary" onClick={ this.decreasePowerHandler }>Decrease Power</button>
            &nbsp;
            &nbsp;
            <input type="range" onInput={ this.setInputPower}/>
            <br/>
            <br/>
            {/* <input ref={this.ipRef} type="number"/> */}
            <input id="box" type="number"/>
            <button onClick={()=> this.setPowerFromNumber() }>set power from number input</button>
           </div>
  }
}

ReactDOM.render(<MainApp/>,document.getElementById('root'));