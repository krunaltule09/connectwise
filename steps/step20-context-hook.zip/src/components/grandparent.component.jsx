import { Component } from 'react';
import FamilyContext from '../context/family.context';
import CousinComponent from './cousin.component';
import ParentComponent from './parent.component';

class GrandParentComponent extends Component{
  state = {
    message : "default message"
  }
  changeMessageHandler = ()=>{
    this.setState({
      message : "Message sent at "+new Date().getSeconds()
    })
  }
  render(){
    return <div style={ {border : "2px solid grey ", padding : "10px", margin : "10px" }}>
            <h1>Grand Parent Component </h1>
            <span>{ this.state.message }</span>
            <br/>
            <button onClick={ this.changeMessageHandler }>Change Message</button>
            <hr/>
            <FamilyContext.Provider value={ this.state.message }>
              <ParentComponent/>
              <hr/>
              <CousinComponent/>
            </FamilyContext.Provider>
           </div>
  }
}

export default GrandParentComponent;