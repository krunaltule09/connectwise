import { Component } from 'react';
import ReactDOM from 'react-dom';

class HeaderComp extends Component{
    render(){
        return <header>
                    <h1>Header Component</h1>
               </header>
    }
}

class ArticleComp extends Component{
    render(){
        return <div>
                <h1>{ this.props.title } | volume : { this.props.vol * 2 }</h1>
               { this.props.children[0].type === 'p' ? 'para found' : 'not a para' }
               { this.props.children[1] }
               <button onClick={ ()=> { this.props.vol += 1 }}>Click to Increase Volume</button>
                <hr/>
               </div>
    }
}

class MainComp extends Component{
    render(){
        return <main>
                <ArticleComp vol={ 101 } title="Part 1 Title">
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Provident, nostrum facilis quos sit ut veniam repudiandae sed porro aliquid? Debitis nostrum rerum obcaecati eligendi, dolorem ullam eius illo facere sapiente.</p>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Provident, nostrum facilis quos sit ut veniam repudiandae sed porro aliquid? Debitis nostrum rerum obcaecati eligendi, dolorem ullam eius illo facere sapiente.</p>
                </ArticleComp>
                <ArticleComp vol={ 102 } title="Part 2 Title">
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Provident, nostrum facilis quos sit ut veniam repudiandae sed porro aliquid? Debitis nostrum rerum obcaecati eligendi, dolorem ullam eius illo facere sapiente.</p>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Provident, nostrum facilis quos sit ut veniam repudiandae sed porro aliquid? Debitis nostrum rerum obcaecati eligendi, dolorem ullam eius illo facere sapiente.</p>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Provident, nostrum facilis quos sit ut veniam repudiandae sed porro aliquid? Debitis nostrum rerum obcaecati eligendi, dolorem ullam eius illo facere sapiente.</p>
                </ArticleComp>
                <ArticleComp vol={ 103 } title="Part 2 Title">
                    <ul>
                        <li> unordered list item 1</li>
                        <li> unordered list item 1</li>
                        <li> unordered list item 1</li>
                    </ul>
                    <ul>
                        <li> ordered list item 1</li>
                        <li> ordered list item 1</li>
                        <li> ordered list item 1</li>
                    </ul>
                </ArticleComp>
               </main>
    }
}
class FooterComp extends Component{
    render(){
        return <footer>
                    <h1>Footer Component</h1>
               </footer>
    }
}

class MainApp extends Component{
    render(){
        return <div>
                    <HeaderComp/>
                    <MainComp/>
                    <FooterComp/>
               </div>
    }
}

ReactDOM.render(<MainApp/>, document.getElementById("root"))