import { Component } from 'react';
import ReactDOM from 'react-dom';

class ChildComp extends Component{
  state = {
    version : 201
  }
  clickHandler(){
      this.setState({
        version : this.state.version + 1
      });
  }
  render(){
    return <div>
            <h1>Child Component Version : { this.state.version }</h1>
{/*             <button onClick={ ()=> { 
              this.setState({
                version : this.state.version + 1
              });
             }}>Increase version</button> */}
            <button onClick={()=>{ this.clickHandler() }}>Increase version</button>
           </div>
  }
}

class MainApp extends Component{
  render(){
    return <div className="container">
            <h1>Welcome to your life</h1>
            <hr/>
            <ChildComp/>
           </div>
  }
}

ReactDOM.render(<MainApp/>,document.getElementById('root'));