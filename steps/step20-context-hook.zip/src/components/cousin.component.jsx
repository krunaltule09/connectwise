import { Component } from 'react';
import FamilyContext from '../context/family.context';

class CousinComponent extends Component{
  render(){
    return <div style={ {border : "2px solid grey ", padding : "10px", margin : "10px" }}>
            <h1>Cousin Component </h1>
            <FamilyContext.Consumer>{
              (val)=>{
                return <h2>{ val }</h2>
              }
              }</FamilyContext.Consumer>
           </div>
  }
}

export default CousinComponent;