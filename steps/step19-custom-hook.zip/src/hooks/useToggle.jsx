import { useState } from "react"

function useToggle(initVal = true){
    let [state, setState] = useState(initVal);

    let toggle = ()=>{
        setState(!state);
    };

    return [state,toggle]
}

export default useToggle;