/* import { Component } from "react";

class ErrorManager extends Component{
    render(){
        return this.props.children
    }
}

export default ErrorManager; */

import { Component } from "react";

class ErrorManager extends Component{
    state = {
        errorMessage : '',
        hasError : false
    }
   /*  static getDerivedStateFromError(err){
        console.log("ErrorManager's getDerivedStateFromError happened");
        console.log(arguments[0]);
        return {
            hasError : true,
            errorMessage : err.message
        }
    } 
    */
    /*  
    */
    componentDidCatch(err){
        console.log("ErrorManager's componentDidCatch happened", arguments[0]);
        this.setState({
            hasError : true,
            errorMessage : err.message
        })
    } 

    render(){
        if(this.state.hasError){
            return <h2>Error : { this.state.errorMessage }</h2>;
        }else{
            return this.props.children;
        }
    }
   
}

export default ErrorManager;