import { Component } from 'react';
import ReactDOM from 'react-dom';
import client from "./client.module.css";

import "./mystyle.css";

class MainApp extends Component{
  inlineStyle = { 
    backgroundColor : 'orchid', 
    padding : '10px', 
    margin : '10px'
  };
  render(){
    return <div className="container">
            <h1>Welcome to your life</h1>
            <p id="boxer" style={this.inlineStyle}>
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Amet sit consequuntur totam facilis reprehenderit ipsam, velit, temporibus numquam itaque quisquam enim repellendus tempore qui animi impedit modi natus officia vel.
            </p>
            <p className="player">
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Amet sit consequuntur totam facilis reprehenderit ipsam, velit, temporibus numquam itaque quisquam enim repellendus tempore qui animi impedit modi natus officia vel.
            </p>
            <p style={this.inlineStyle}>
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Amet sit consequuntur totam facilis reprehenderit ipsam, velit, temporibus numquam itaque quisquam enim repellendus tempore qui animi impedit modi natus officia vel.
            </p>
            <p className={ client.player }>
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Amet sit consequuntur totam facilis reprehenderit ipsam, velit, temporibus numquam itaque quisquam enim repellendus tempore qui animi impedit modi natus officia vel.
            </p>
           </div>
  }
}

ReactDOM.render(<MainApp/>,document.getElementById('root'));